#include <stdio.h>
#include "control.h"

ctrlInfo c = {0,0,0,0};
waysideInfo w; 

void update_ctrl_info(ctrlInfo* ctrl){
	c.cmdv = ctrl->cmdv;
	c.ebv = ctrl->ebv;
	c.pos = ctrl->pos;
	c.v = ctrl->v;
}
void update_wayside_info(waysideInfo *wayside){
	w.data[0] = wayside->data[0];
	w.slope = wayside->slope;
	w.speed = wayside->speed;
}
int8_t getLevel(ctrlInfo* ctrl,waysideInfo* wayside){
	int8_t ret = 0;
	ret = (c.v - w.speed)%10;
	printf("in get level: %d\r\n",w.data[0]);
	return ret;
}